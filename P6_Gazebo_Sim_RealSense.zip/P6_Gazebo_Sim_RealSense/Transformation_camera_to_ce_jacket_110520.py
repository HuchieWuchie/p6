
import numpy as np
import transformations as tf
from scipy.spatial.transform import Rotation as R

theta_x=1.56                   
theta_y_r=0.45                   
theta_z_r=-1 
#theta_y_neg=-1.56                 

x_tr_r=np.array((0,2.5,3,1))  # camera position in gazebo x=0.6; y=2.5; z=3.2; 
T_x_r=tf.translation_matrix(x_tr_r) #ce_jacket rotation
# I=tf.identity_matrix()
Rot_x=tf.rotation_matrix(theta_x,(1,0,0))
Rot_y_r=tf.rotation_matrix(theta_y_r,(0,1,0))
#Rot_y_neg=tf.rotation_matrix(theta_y_neg,(0,1,0))
Rot_z_r=tf.rotation_matrix(theta_z_r,(0,0,1))
#print(Rot_x)
print (np.matrix.round(((T_x_r).dot(Rot_z_r).dot(Rot_y_r)),3))
print (np.matrix.round(((Rot_x).dot(T_x_r).dot(Rot_z_r).dot(Rot_y_r)),3))
#print (np.matrix.round(((Rot_y_neg).dot(Rot_x).dot(T_x_r).dot(Rot_z_r).dot(Rot_y_r)),3))
#print (np.matrix.round(((Rot_x).dot(T_x_r).dot(Rot_z_r).dot(Rot_y_r)),3))
#Cartesian poses (vector representation)
#camera placed from the right side from ce_jacket
camera_pose_gazebo=[0.6,2.5,3.2,0,0.51,-1.56]
#ce_jacket pose
ce_jacket_pose=[0,0,0,1.56,0,0]
'''

theta_x=1.56                   
theta_x_r=0.51                   
theta_y_r=0.51                  

x_tr_r=np.array((3.66,0.5,-1.75,1))  # camera position in gazebo x=0.6; y=2.5; z=3.2; 
T_x_r=tf.translation_matrix(x_tr_r) #ce_jacket rotation
# I=tf.identity_matrix()
Rot_x=tf.rotation_matrix(theta_x,(1,0,0))
Rot_x_r=tf.rotation_matrix(theta_y_r,(1,0,0))
Rot_y_r=tf.rotation_matrix(theta_y_r,(0,1,0))
#print(Rot_x)
print (np.matrix.round(((T_x_r).dot(Rot_y_r).dot(Rot_x_r)),3))
print (np.matrix.round(((T_x_r).dot(Rot_x_r).dot(Rot_y_r)),3))
#print (np.matrix.round(((Rot_x).dot(T_x_r).dot(Rot_z_r).dot(Rot_y_r)),3))

'''
       [x,y,x,roll,pitch,yaw]
    0. [0,2.5,3.0,0,0.45,-1]
    1. [2.0,2.7,3.0,0,0.45,-1.56]
    2. [5.0,0.0,3.0,0,0.43,3.14]
    3. [5.0,-2.0,3.0,0,0.43,2.56]
    4. [0.0,3.7,3.0,0,0.45,1.1]




